﻿document.createElement('header');
document.createElement('menu');
document.createElement('section');
document.createElement('hgroup');